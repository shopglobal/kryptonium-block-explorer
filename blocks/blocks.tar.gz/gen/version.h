//
// Created by mwo on 23/11/16.
//

#ifndef XMRBLOCKS_VERSION_H_IN_H
#define XMRBLOCKS_VERSION_H_IN_H

#define GIT_BRANCH "master"
#define GIT_COMMIT_HASH "7c6b418"
#define GIT_COMMIT_DATETIME "2018-02-23"
#define GIT_BRANCH_NAME "master"


#endif //XMRBLOCKS_VERSION_H_IN_H
