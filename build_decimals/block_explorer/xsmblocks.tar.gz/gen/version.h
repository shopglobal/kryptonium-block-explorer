//
// Created by mwo on 23/11/16.
//

#ifndef XMRBLOCKS_VERSION_H_IN_H
#define XMRBLOCKS_VERSION_H_IN_H

#define GIT_BRANCH "master"
#define GIT_COMMIT_HASH "40fb44f"
#define GIT_COMMIT_DATETIME "2018-03-03"
#define GIT_BRANCH_NAME "master"


#endif //XMRBLOCKS_VERSION_H_IN_H
